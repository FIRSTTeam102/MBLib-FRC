# ntcore TODO

## Functionality

* Initial connection flag

## Unit Test Coverage

* Message class
* SequenceNumber class
* NetworkCommunication class
* Dispatcher class
* Storage incoming processing
* Keepalives
* Notifiers
* RPC
* C++ API
* C API
* SavePersistent safe file handling (part of C++ API)
* More LoadPersistent warning cases
* Automatic persistent saves
